var1=int(input("introduce el primer numero: "))
var2=int(input("introduce el segundo numero: "))

div_entera=var1//var2
print("el resultado de la division entera es: ",div_entera)
