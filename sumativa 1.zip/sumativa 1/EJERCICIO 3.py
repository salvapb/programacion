import math
var1=float(input("introduce el valor de un lado: "))
area=math.sqrt(3)/4*var1**2
print("el area es: ",round{area},2)
