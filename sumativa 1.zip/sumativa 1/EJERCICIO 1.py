var1=float(input("introduce el primer numero: "))
#he puesto int para identificar que se debe introducir un numero y no una letra

var2=float(input("introduce el segundo numero: "))
#hay que introducir el texto entre comillas""

var_total=var1+var2

#no puede haber espacios entre la variable y en la hoja var1 y var 2 estan escritos diferentes

print(f"el resultado de la suma de {var1} y {var2} es: ",var_total)

#en la hoja escribe var_total diferente


