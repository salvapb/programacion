var1=float(input("introduce el primer numero: "))
var2=float(input("introduce el segundo numero: "))
var_total=var1+var2
print(f"el resultado de sumar {var1} y {var2} es: ",var_total)

var_div=var_total/3

print(f"el resultado de la division de {var_total} entre 3 es: ",var_div)
