#9. programa que pida los segundos y muestre por pantalla y en la misma frase los minutos y las horas

var1=int(input("introduce los segundos: "))
minutos=var1/60
horas=var1/3600
print("los minutos son: ",minutos)
print("las horas son: ",horas)
