#3. Programa que pida dos números enteros y realice la suma correspondiente
var1=int(input("introduce el primer numero: "))
var2=int(input("introduce el segundo numero: "))
total=var2+var1
print("la suma de los dos numeros es: ",total)
