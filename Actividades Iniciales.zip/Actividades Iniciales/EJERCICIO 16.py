import math
var1=int(input("introduce un numero: "))
print(math.sqrt(var1))
print(round(math.sqrt(var1)/2))
