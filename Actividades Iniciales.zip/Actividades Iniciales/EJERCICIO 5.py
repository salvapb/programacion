#5. Programa que pida cinco palabras y muestre una frase con las cinco. Modifica el código para que entre palabra y palabra haya una coma

var1=input("introduce la primera palabra: ")
var2=input("introduce la segunda palabra: ")
var3=input("introduce la tercera palabra: ")
var4=input("introduce la cuarta palabra: ")
var5=input("introduce la quinta palabra: ")
print(var1,",",var2,",",var3,",",var4,",",var5)
