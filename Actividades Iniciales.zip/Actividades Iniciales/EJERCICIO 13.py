var1=float(input("introduce el valor de uno de los lados: "))
volumen=var1**3
area=var1**2*6
print("el area es: ",area)
print("el volumen es: ",volumen)
