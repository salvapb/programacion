#1.programa que muestre por pantalla la frase "hello world"
print("hello world")
