#2. Programa que introduzca por teclado tres tipos de variables y se muestren por pantalla en el siguiente orden:numero entero,texto y numero decimal
var1=int(input("introduce un numero: "))
var2=input("introduce una letra: ")
var3=float(input("introuce un numero decimal: "))
print("el numero entero es:",var1)
print("la letra introducida es:",var2)
print("el numero decimal es:",var3)
