var1=int(input("introduce el primer operador: "))
var2=int(input("introduce el segundo operador: "))
suma=var1+var2 
print("la suma de los dos operadores es: ",suma)
resta=var1-var2
print("la resta de los dos operadores es: ",resta)
division=var1/var2
print("la division de los dos operadores es: ",division)
exponente=var1**var2
print("el exponente de los dos operadores es: ",exponente)
division_entera=var1//var2
print("la division entera de los dos operadores es: ",division_entera)

