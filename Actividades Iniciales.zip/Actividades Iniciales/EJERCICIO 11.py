#11. Realiza un programa que introduciendo el valor del lado de un cuadrado nos devuelva por pantalla en el área y el perímetro.

var1=int(input("introduce un lado del cuadrado: "))
area=var1**2
perimetro=var1*4
print("el perimetro es: ", perimetro)
print("el area es: ",area)
