import math
var1=int(input("introduce el valor del diametro: "))
perimetro=round(2*math.pi*(var1/2))
print("el perimetro es: ",perimetro)
area=round(math.pi*(var1/2)**2)
print("el area es: ", area)
