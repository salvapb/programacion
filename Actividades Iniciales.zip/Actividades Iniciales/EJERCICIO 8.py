#8. programa que pida un número de horas y muestre por pantalla los minutos y segundos
var1=int(input("introduce el numero de horas: "))
minutos=var1*60
segundos=var1*3600
print("los minutos son: ",minutos)
print("los segundos son: ",segundos)
