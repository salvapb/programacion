#4. A partir del código anterior, realiza una versión para números con decimales
var1=float(input("introduce el primer número: "))
var2=float(input("introduce el segundo número: "))
total=var1+var2
print("la suma de los dos numeroses: ",total)
