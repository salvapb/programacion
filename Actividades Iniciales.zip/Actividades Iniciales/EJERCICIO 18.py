var1=int(input("introduce el numero de menores: "))
var2=int(input("introduce el numero de adultos: "))
precios_menores=12/2*var1
print("el precio de los menores es: ",precios_menores)
precio_adultos=12/1.1111*var2
print("el precio de los adultos es: ",precio_adultos)
