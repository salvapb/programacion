#6. A partir del programa 5. Haz que se muestre por pantalla también la frase en el orden inverso en que se han introducido las palabras.
var1=input("introduce la primera palabra: ")
var2=input("introduce la segunda palabra: ")
var3=input("introduce la tercera palabra: ")
var4=input("introduce la cuarta palabra: ")
var5=input("introduce la quinta palabra: ")
print(var5,",",var4,",",var3,",",var2,",",var1)
